#!/bin/python3

#main

import pygame
from tiledata import *
from config import *
from player import *
from medic import *
from shovel import *
from button import *
import leveldata
from rover import *
import sys

class Game:
    def __init__(self):

        # main init
        
        pygame.init()
        self.screen = pygame.display.set_mode((WinWidth, WinHeight), pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        pygame.mixer.pre_init(44100, 16, 2, 32) #frequency, size, channels, buffersize
        self.title = pygame.display.set_caption('Cambria')
        self.iconpng = pygame.image.load('Assets/icon.png')
        self.icon = pygame.display.set_icon(self.iconpng)
        self.running = True

        # font init

        pygame.font.init()
        self.font = pygame.font.Font('Assets/PixelOperator-Bold.ttf', 32)

        # map loading init
        
        self.tilemap = leveldata.tilemap01()
        self.startx = 7
        self.starty = 12

        # game element variable loading
        
        self.hp = 100
        self.hasShovel = False

        # loading images

        self.playerspritesheet = spritesheet('Assets/playerspritesheet.png')
        self.doctorspritesheet = spritesheet('Assets/doctorspritesheet.png')
        self.grass = spritesheet('Assets/grass.png')
        self.void = spritesheet('Assets/void.png')
        self.stonebricks = spritesheet('Assets/stonebricks.png')
        self.roverspritesheet = spritesheet('Assets/roverspritesheet.png')
        self.intro_background = pygame.image.load('Assets/gradient.png')
        self.gameover_background = pygame.image.load('Assets/gameover.png')
        self.shovelspritesheet = spritesheet('Assets/shovelspritesheet.png')
        self.shovel_col = spritesheet('Assets/shovel_col.png')

        # loading sound and music

        self.death_sound = pygame.mixer.Sound('Assets/death.ogg')

    def setTilemap(self, tilemap):
        print('user entered', tilemap)
        print('there are', self.rovers, 'rovers')
        mapdata = getattr(leveldata, tilemap[0])
        self.tilemap = mapdata()
        self.startx = tilemap[1]
        self.starty = tilemap[2]
        self.new()

    def TileCreate(self):
        self.rovers = 0
        self.ConditionHasBeenMet = False
        for i, row in enumerate(self.tilemap.mapdata):
            for j, column in enumerate(row):
                grass(self, j, i)
                if column == '1':
                    block(self, j, i)
                if column == 'R':
                    rover(self, j, i)
                    self.rovers += 1
                if column == 'T':
                    map_change_trigger(self, j, i)
                if column == 'S':
                    if self.hasShovel == False:
                        shovel_col(self, j, i)
                    else:
                        grass(self, j, i)
                if column == '?': # this is a really important formula I will be using several more times later
                    ret = random.choice(('rover', 'grass', 'block'))
                    if ret == 'grass':
                        grass(self, j, i)
                    if ret == 'block':
                        block(self, j, i)
                    if ret == 'rover':
                        rover(self, j, i)
                if column == 'V':
                    voidblock(self, j, i)
                if column == 'D':
                    medic(self, j, i)
                if column == 't':
                    if self.ConditionHasBeenMet == True:
                        grass(self, j, i)
                    else:
                        block(self, j, i)
                if column == 's':
                    if self.ConditionHasBeenMet == True:
                        block(self, j, i)
                    else:
                        grass(self, j, i)

    def new(self):
        self.playing = True
        self.all_sprites = pygame.sprite.LayeredUpdates()
        self.tiles = pygame.sprite.LayeredUpdates()
        self.blocks = pygame.sprite.LayeredUpdates()
        self.buildings = pygame.sprite.LayeredUpdates()
        self.enemies = pygame.sprite.LayeredUpdates()
        self.attacks = pygame.sprite.LayeredUpdates()
        self.weapons = pygame.sprite.LayeredUpdates()
        self.guns = pygame.sprite.LayeredUpdates()
        self.shovelpickup = pygame.sprite.LayeredUpdates()
        self.triggers = pygame.sprite.LayeredUpdates()
        self.medic = pygame.sprite.LayeredUpdates()
        self.player = Player(self, self.startx, self.starty)

        self.TileCreate()

    def gui(self):
        
        self.hpdisplay = self.font.render('HP: {hp}'.format(hp=self.hp), True, white)
        self.hpdisplay_rect = self.hpdisplay.get_rect(x=10, y=10)
        self.screen.blit(self.hpdisplay, self.hpdisplay_rect)
        
    def events(self):
            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.playing = False
                self.running = False
            if event.type == pygame.MOUSEBUTTONDOWN and self.hasShovel == True:
                if event.button == 1:
                    if self.player.facing == 'up':
                        shovel(self, self.player.rect.x, self.player.rect.y - TileSize)
                        
                    if self.player.facing == 'down':
                        shovel(self, self.player.rect.x, self.player.rect.y + TileSize)
                        
                    if self.player.facing == 'left':
                        shovel(self, self.player.rect.x - TileSize, self.player.rect.y)
                        
                    if self.player.facing == 'right':
                        shovel(self, self.player.rect.x + TileSize, self.player.rect.y)

    def update(self):
        self.all_sprites.update()
        
    def draw(self):
        self.all_sprites.draw(self.screen)
        self.clock.tick(FPS)
        self.gui()
        pygame.display.update()

    def main(self):
        # game loop
        while self.playing:
            self.events()
            self.update()
            self.draw()

    def game_over(self):
        pygame.mixer.music.fadeout(100)
        text = self.font.render('You have tragically passed away.', True, white)
        text_rect = text.get_rect(x=10, y=10)
        
        continue_button = Button(10, 100, 140, 50, white, black, 'Continue?', 32)

        self.death_sound.play()

        for sprite in self.all_sprites:
            sprite.kill()

        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            mouse_pos = pygame.mouse.get_pos()
            mouse_pressed = pygame.mouse.get_pressed()

            if continue_button.is_pressed(mouse_pos, mouse_pressed):
                self.hp = 100
                self.new()
                self.overworld_1 = pygame.mixer.music.load('Assets/chopinoverworld.ogg')
                pygame.mixer.music.play(-1)
                self.main()

            self.screen.blit(self.gameover_background, (0,0))
            self.screen.blit(text, text_rect)
            self.screen.blit(continue_button.image, continue_button.rect)
            self.clock.tick(FPS)
            pygame.display.update()
            

    def intro_screen(self):
        intro = True
        
        splash = self.font.render(random.choice(('Alpha 03!', 'Made in Canada', 'Made by Kecenr', 'Rovers... Rovers everywhere!', 'Ceci n\'est pas une title screen!', 'Do a barrel roll!', 'Oh my god, we\'re doOoOoOomed!', 'About that beer I owed ya!', 'It\'s dangerous to go alone! Take this!', 'Press alt+f4!', 'Impending doom approaches...', 'Here\'s a realistic elephant...', 'Looks just like Buddy Holly!', '6\'4\" and full of muscle!', 'Rip and tear!', 'Here to kick ass and chew bubblegum!', 'Put dispenser here!', 'Your mind is filled with thoughts of Cambria!', 'Ayyy, lmao!', 'Door stuck! DOOR STUCK!', 'Fus Ro Dah!', 'DO. NOT. SEEK. THE TREASURE!')), True, teal)
        splash_rect = splash.get_rect(x=10, y=35)
        
        title = self.font.render('Cambria', True, white)
        title_rect = title.get_rect(x=10, y=10)
        self.titlescreenmusic = pygame.mixer.music.load('Assets/gymnopedie.ogg')
        pygame.mixer.music.play(-1)

        play_button = Button(-5, 100, 100, 50, white, black, 'PLAY', 32)

        while intro:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    intro = False
                    self.running = False

            mouse_pos = pygame.mouse.get_pos()
            mouse_pressed = pygame.mouse.get_pressed()

            if play_button.is_pressed(mouse_pos, mouse_pressed):
                pygame.mixer.music.fadeout(500)
                self.overworld_1 = pygame.mixer.music.load('Assets/chopinoverworld.ogg')
                pygame.mixer.music.play(-1)
                intro = False

            self.screen.blit(self.intro_background, (0, 0))
            self.screen.blit(title, title_rect)
            self.screen.blit(splash, splash_rect)
            self.screen.blit(play_button.image, play_button.rect)
            self.clock.tick(FPS)
            pygame.display.update()

g = Game()
g.intro_screen()
g.new()
while g.running:
    g.main()
    g.game_over()

pygame.quit()
sys.exit()
    
