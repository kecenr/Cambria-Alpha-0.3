from graphics_init import *

class medic(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = foe_layer
        self.groups = self.game.medic, self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)
        pygame.mixer.pre_init(44100, 16, 2, 32) #frequency, size, channels, buffersize

        self.x = x * TileSize
        self.y = y * TileSize
        self.x_change = 0
        self.y_change = 0

        self.facing = 'down'
        self.an_loop = 0
        self.footstep_timer = 0

        self.width = TileSize
        self.height = TileSize

        self.image = self.game.doctorspritesheet.get_sprite(0, 0, 32, 32)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
        self.max_travel = random.randint(32, 64)
        self.move_loop = 0
        
    def update(self):
    
        self.movement()
        self.animation()
        self.rect.x += self.x_change
        self.collision('x')
        self.rect.y += self.y_change
        self.collision('y')

        self.x_change = 0
        self.y_change = 0
        
    def movement(self):

        if self.facing == 'left':
            self.x_change -= 3
            self.move_loop -= 1
            if self.move_loop <= -self.max_travel:
                self.facing = random.choice(['right', 'up', 'down'])

        elif self.facing  == 'right':
            self.x_change += 3
            self.move_loop += 1
            if self.move_loop >= self.max_travel:
                self.facing = random.choice(['left', 'up', 'down'])
                
        elif self.facing  == 'up':
            self.y_change -= 3
            self.move_loop += 1
            if self.move_loop >= self.max_travel:
                self.facing = random.choice(['right', 'left', 'down'])
                
        elif self.facing  == 'down':
            self.y_change += 3
            self.move_loop += 1
            if self.move_loop >= self.max_travel:
                self.facing = random.choice(['right', 'up', 'left'])

        elif self.facing == 'idle':
            self.idle += 1
            self.x_change = 0
            self.y_change = 0
            self.move_loop = 0
            if (self.idle > 100):
                self.facing = random.choice(['left', 'right', 'up', 'down'])
        
    def collision(self, direction):
        if direction == 'x':
            hits = pygame.sprite.spritecollide(self, self.game.blocks, False)
            if hits:
                if self.x_change > 0:
                    self.rect.x = hits[0].rect.left - self.rect.width
                    self.facing = 'left'
                if self.x_change < 0:
                    self.rect.x = hits[0].rect.right
                    self.facing = 'right'

        if direction == 'y':
            hits = pygame.sprite.spritecollide(self, self.game.blocks, False)
            if hits:
                if self.y_change > 0:
                    self.rect.y = hits[0].rect.top - self.rect.height
                    self.facing = 'up'
                if self.y_change < 0:
                    self.rect.y = hits[0].rect.bottom
                    self.facing = 'down'
                    
    def animation(self):

        right_walk = [self.game.doctorspritesheet.get_sprite(64, 0, self.width, self.height), # left foot
                             self.game.doctorspritesheet.get_sprite(32, 0, self.width, self.height)] # right foot

        left_walk = [self.game.doctorspritesheet.get_sprite(128, 0, self.width, self.height), # left foot
                           self.game.doctorspritesheet.get_sprite(160, 0, self.width, self.height)] # right foot

        down_walk = [self.game.doctorspritesheet.get_sprite(224, 0, self.width, self.height), # left foot
                             self.game.doctorspritesheet.get_sprite(256, 0, self.width, self.height)] # right foot

        up_walk = [self.game.doctorspritesheet.get_sprite(320, 0, self.width, self.height), # left foot
                         self.game.doctorspritesheet.get_sprite(352, 0, self.width, self.height)] # right foot

        if self.facing == 'right':
            if self.x_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = right_walk[math.floor(self.an_loop)]
                self.an_loop += 0.1 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0

        if self.facing == 'left':
            if self.x_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(96, 0, self.width, self.height)
            else:
                self.image = left_walk[math.floor(self.an_loop)]
                self.an_loop += 0.1 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0

        if self.facing == 'down':
            if self.y_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(192, 0, self.width, self.height)
            else:
                self.image = down_walk[math.floor(self.an_loop)]
                self.an_loop += 0.1 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0

        if self.facing == 'up':
            if self.y_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(288, 0, self.width, self.height)
            else:
                self.image = up_walk[math.floor(self.an_loop)]
                self.an_loop += 0.1 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0
