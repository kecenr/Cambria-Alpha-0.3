# shovel

from graphics_init import *

class shovel(pygame.sprite.Sprite):
    
    def __init__(self, game, x, y):

        self.game = game
        self._layer = ui_layer # even though the shovel is not part of the UI
        self.groups = self.game.all_sprites, self.game.weapons
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x
        self.y = y
        self.width = TileSize
        self.height = TileSize
        self.x_change = 0
        self.y_change = 0

        self.image = self.game.shovelspritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        self.an_loop = 0

    def update(self):
        self.animation()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.direction()

    def collision(self):
        hits = pygame.sprite.spritecollide(self, self.game.enemies, True)

    def animation(self):
        if self.game.player.facing == 'left':
            self.game.player.isMelee = True
            self.an_loop += 1
            if self.an_loop < 5:
                self.x_change = -1
            if self.an_loop > 5:
                self.x_change = 1
            if self.an_loop > 10:
                self.kill()
                self.game.player.isMelee = False
                
        if self.game.player.facing == 'right':
            self.game.player.isMelee = True
            self.an_loop += 1
            if self.an_loop < 5:
                self.x_change = 1
            if self.an_loop > 5:
                self.x_change = -1
            if self.an_loop > 10:
                self.kill()
                self.game.player.isMelee = False
                
        if self.game.player.facing == 'down':
            self.game.player.isMelee == True
            self.an_loop += 1
            if self.an_loop < 5:
                self.y_change = 1
            if self.an_loop > 5:
                self.y_change = -1
            if self.an_loop > 10:
                self.kill()
                self.game.player.isMelee = False
                
        if self.game.player.facing == 'up':
            self.game.player.isMelee == True
            self.an_loop += 1
            if self.an_loop < 5:
                self.y_change = -1
            if self.an_loop > 5:
                self.y_change = 1
            if self.an_loop > 10:
                self.kill()
                self.game.player.isMelee = False          

    def direction(self):

        if self.game.player.facing == 'right':
            self.image = self.game.shovelspritesheet.get_sprite(0, 0, self.width, self.height)

        if self.game.player.facing == 'left':
            self.image = self.game.shovelspritesheet.get_sprite(32, 0, self.width, self.height)

        if self.game.player.facing == 'down':
            self.image = self.game.shovelspritesheet.get_sprite(64, 0, self.width, self.height)

        if self.game.player.facing == 'up':
            self.image = self.game.shovelspritesheet.get_sprite(96, 0, self.width, self.height)

class shovel_col(pygame.sprite.Sprite):
    
    def __init__(self, game, x, y):

        self.game = game
        self._layer = ground_layer
        self.groups = self.game.all_sprites, self.game.shovelpickup
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize

        self.width = TileSize
        self.height = TileSize

        self.image = self.game.shovel_col.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
